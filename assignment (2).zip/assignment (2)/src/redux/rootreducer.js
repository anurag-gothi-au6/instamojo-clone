import {combineReducers} from 'redux'
import paymentReducer from './reducers/paymentReducer'
import detailsReducer from './reducers/detailReducer'
const rootReducer = combineReducers({
    paymentState: paymentReducer,
    detailState:detailsReducer
})

export default rootReducer