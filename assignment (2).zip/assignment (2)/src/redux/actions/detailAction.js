import {CURRENT_DETAIL} from '../actionType'

export const addDetails = (data)=> dispatch =>{
    dispatch({type:CURRENT_DETAIL,payload:null})
    dispatch({type:CURRENT_DETAIL,payload:data})
}