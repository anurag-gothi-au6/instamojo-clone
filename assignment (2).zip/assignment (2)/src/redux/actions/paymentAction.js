import {CURRENT_PAYMENT} from '../actionType'

export const doPayment = (data)=> dispatch =>{
    dispatch({type:CURRENT_PAYMENT,payload:null})
    dispatch({type:CURRENT_PAYMENT,payload:data})
}