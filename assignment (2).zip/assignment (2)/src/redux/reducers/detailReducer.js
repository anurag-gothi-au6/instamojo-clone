import {CURRENT_DETAIL} from '../actionType'
const initialState = {
    details:null
} 
const detailsReducer = (state=initialState,action) =>{
    const {type,payload} = action
    switch(type)  {
        case CURRENT_DETAIL:
            return {...state,details:payload}
        default:
            return state
    } 

}
export default detailsReducer