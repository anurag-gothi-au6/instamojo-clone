import {CURRENT_PAYMENT} from '../actionType'
const initialState = {
    payment:null
} 
const paymentReducer = (state=initialState,action) =>{
    const {type,payload} = action
    switch(type)  {
        case CURRENT_PAYMENT:
            return {...state, payment:payload}
        default:
            return state
    } 

}
export default paymentReducer