import React from 'react';
import './App.css';
import {Switch, Route, Redirect} from 'react-router-dom'
import Homepage from './components/HomePage'
import Navbar from './components/Navbar'
import PaymentDetails from './components/PaymenDetail'
import CheckoutPage from './components/CheckoutPage'
function App() {
  return (
    <div className="App">
      <div className='container'>
      <Navbar></Navbar>
      <Switch>
        <Route exact path='/' component={Homepage}/>
        <Route exact path='/detail' component={PaymentDetails}/>
        <Route exact path='/checkout' component={CheckoutPage}/>
        <Redirect to='/' />
      </Switch>
      </div>
    </div>
  );
}


export default App;
