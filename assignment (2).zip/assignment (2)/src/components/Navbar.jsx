import React from 'react'

const Navbar = () => {
    return (
        <div className='navbar'>
            <img src='https://media.instamojo.com/imgs/179a276d106d46d591228d0ec5a8cd05.jpg' alt='logo' style={{display:'inline-block',float:'left',height:'40px',width:'40px', verticalAlign:'middle',marginTop:'5px',borderRadius:'30%'}}/>
            <p style={{marginLeft:'65px'}}>Paying To <br></br> Exposys data labs</p>
            {/* <p style={{marginLeft:'65px'}}>Exposys data labs</p> */}
        </div>
    )
}

export default Navbar
