import React from "react";
import { Input } from "antd";
import { connect } from "react-redux";
import { doPayment } from "../redux/actions/paymentAction";
class HomePage extends React.Component {
  state = {
    purpose: "",
    amount: "",
    errors: null,
  };
  handleChange = (e) => {
    this.setState({ error: [] });
    this.setState({ [e.target.name]: e.target.value });
  };
  handleChangeNumber = (e) => {
    this.setState({ error: [] });
    if (!isNaN(e.target.value)) {
      this.setState({ [e.target.name]: e.target.value });
    }
  };
  handleSubmit = (e) => {
    e.preventDefault();
    const { purpose, amount } = this.state;
    console.log(amount);
    if (isNaN(amount)) {
      this.setState({ errors: "Please Enter a valid Amount" });
    }
    if (!amount) {
      this.setState({ errors: "Please Enter a Amount" });
    } else {
      const data = {
        purpose: purpose,
        amount: amount,
      };
      this.props.doPayment(data);
      this.props.history.push('/detail')
    }
  };
  render() {
    return (
      <div className="home">
        <form onSubmit={this.handleSubmit}>
          <p className="grey">Purpose of payment</p>
          <Input
            type="text"
            value={this.state.purpose}
            name="purpose"
            onChange={this.handleChange}
          ></Input>
          <p className="grey">Amount</p>
          <Input
            type="text"
            value={this.state.amount}
            onChange={this.handleChangeNumber}
            name="amount"
            addonBefore="₹"
          ></Input>
          <p style={{ color: "red" }}>{this.state.errors}</p>
          <Input
            className="submit"
            style={{
              marginTop: "10px",
              backgroundColor: "#4BAC58",
              color: "white",
              height: "40px",
            }}
            type="submit"
            value="pay now"
          ></Input>
        </form>
      </div>
    );
  }
}

export default connect(null, { doPayment })(HomePage);
