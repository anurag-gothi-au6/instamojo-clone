import React, { Component } from "react";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import { Divider, Breadcrumb } from "antd";
import { addDetails } from "../redux/actions/detailAction";
import QrCode from "qrcode.react";
class PaymenDetail extends Component {
  state = {
    toggle: false,
  };
  toggleHandler = () => {
    this.setState({ toggle: !this.state.toggle });
  };

  render() {
    return (
      <div>
        {this.props.payment !== null ? (
          <div className="home">
            <p className="grey">Purpose of payment</p>
            <p>{this.props.payment.purpose}</p>
            <p style={{ float: "left" }}>Amount</p>
            <p style={{ float: "right" }} className="bold">
              ₹{this.props.payment.amount}
            </p>
            <Divider />
            <p style={{ float: "left" }} className="bold">
              Total
            </p>
            <p style={{ float: "right" }} className="bold">
              ₹{this.props.payment.amount}
            </p>
            <Divider />
            <Breadcrumb>
              <Breadcrumb.Item>Your Detail</Breadcrumb.Item>
              <Breadcrumb.Item>Payment</Breadcrumb.Item>
            </Breadcrumb>
            <Divider />
            {this.state.toggle === false ? (
              <div>
                <div className="border">
                  <QrCode value="https://www.kreditpaisa.com/"></QrCode>
                  <h3 className="grey">Scan & Pay</h3>
                  <h2>₹{this.props.payment.amount}</h2>
                  <Divider plain>Or</Divider>
                  <button className="primary-btn" >Enter Upi ID</button>
                </div>
                <button className='more' onClick={this.toggleHandler}>
                  More Payment Options <span style={{float:'right'}}>▼</span>
                </button>
              </div>
            ) : (
              <div>
                <button className='more' onClick={this.toggleHandler}>
                  Scan UPI QR and pay <span style={{float:'right'}}>▼</span>
                </button>

                <div className="border">
                  <h2>More payment options</h2>
                  <button className="primary-btn" >Credit/ debit card</button>
                  <button className="primary-btn" >Netbanking</button>
                  <button className="primary-btn" >Wallet</button>
                  <button className="primary-btn" >Pay Later</button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <Redirect to="/" />
        )}
      </div>
    );
  }
}

const mapStateToProps = (storeState) => {
  return {
    payment: storeState.paymentState.payment,
  };
};

export default connect(mapStateToProps, { addDetails })(PaymenDetail);
