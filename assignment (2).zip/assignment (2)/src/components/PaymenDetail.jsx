import React, { Component } from "react";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import { Divider, Breadcrumb, Input } from "antd";
import { addDetails } from "../redux/actions/detailAction";
class PaymenDetail extends Component {
  state = {
    name: "",
    email: "",
    phone: "",
    NameError: "",
    PhoneError: "",
    EmailError: "",
  };
  handleChange = (e) => {
    this.setState({ PhoneError: "" });
    this.setState({ NameError: "" });
    this.setState({ EmailError: "" });
    this.setState({ [e.target.name]: e.target.value });
  };
  handleChangeNumber = (e) => {
    this.setState({ PhoneError: "" });
    if (!isNaN(e.target.value)) {
      this.setState({ [e.target.name]: e.target.value });
    }
  };
  handleSubmit = (e) => {
    e.preventDefault();
    const { name, email, phone } = this.state;
    if (isNaN(phone)) {
      this.setState({ PhoneError: "Please Enter a valid Number" });
    }
    if (!phone || phone.length!==10) {
      this.setState({ PhoneError: "Please Enter Phone Number" });
    }

    if (!email) {
      this.setState({ EmailError: "Please Enter Email" });
    }
    if (!name) {
      this.setState({ NameError: "Please Enter Name" });
    } else {
      const data = {
        name: name,
        email: email,
        phone: phone,
      };
      this.props.addDetails(data);
        this.props.history.push('/checkout')
    }
  };
  render() {
    return (
      <div>
        {this.props.payment !== null ? (
          <div className="home">
            <p className="grey">Purpose of payment</p>
            <p>{this.props.payment.purpose}</p>
            <p style={{ float: "left" }}>Amount</p>
            <p style={{float:'right'}} className="bold">₹{this.props.payment.amount}</p>
            <Divider />
            <Breadcrumb>
              <Breadcrumb.Item>Your Detail</Breadcrumb.Item>
              <Breadcrumb.Item>Payment</Breadcrumb.Item>
            </Breadcrumb>
            <Divider />
            <form onSubmit={this.handleSubmit}>
              <p className="grey">Name</p>
              <Input
                type="text"
                value={this.state.name}
                name="name"
                onChange={this.handleChange}
              ></Input>
              <p style={{ color: "red" }}>{this.state.NameError}</p>

              <p className="grey">email</p>
              <Input
                type="email"
                value={this.state.email}
                onChange={this.handleChange}
                name="email"
              ></Input>
              <p style={{ color: "red" }}>{this.state.EmailError}</p>

              <p className="grey">Phone Number</p>
              <Input
                type="text"
                value={this.state.phone}
                onChange={this.handleChangeNumber}
                name="phone"
                addonBefore="+91"
              ></Input>
              <p style={{ color: "red" }}>{this.state.PhoneError}</p>

              <Divider />
              <p style={{ float: "left" }} className="bold">
                Amount
              </p>
              <p style={{float:'right'}} className="bold">₹{this.props.payment.amount}</p>
              <Divider />
              <Input
                className="submit"
                style={{
                  marginTop: "10px",
                  backgroundColor: "#4BAC58",
                  color: "white",
                  height: "40px",
                }}
                type="submit"
                value="Next"
              ></Input>
            </form>
          </div>
        ) : (
          <Redirect to="/" />
        )}
      </div>
    );
  }
}

const mapStateToProps = (storeState) => {
  return {
    payment: storeState.paymentState.payment,
  };
};

export default connect(mapStateToProps, { addDetails })(PaymenDetail);
